//nav menu
function myFunction() {
  var element = document.getElementById("myDIV");
  element.classList.toggle("show");
}
