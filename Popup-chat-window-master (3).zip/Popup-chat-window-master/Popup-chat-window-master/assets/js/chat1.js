let audio1 = new Audio("https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/clickUp.mp3");
 
function generateRandomUserId() {
  return 'u' + Math.floor(Math.random() * 1000).toString().padStart(3, '0');
}
 
function updateUrlParams() {
  const urlParams = new URLSearchParams(window.location.search);
  const generatedId = urlParams.get('generatedId');
  let userId = urlParams.get('userId');
 
  if (!generatedId) {
    alert("Please provide a generatedId in the URL.");
    return;
  }
 
  if (!userId) {
    userId = generateRandomUserId();
    urlParams.set('userId', userId);
  }
 
  urlParams.set('generatedId', generatedId);
 
  window.history.replaceState({}, '', `${window.location.pathname}?${urlParams}`);
 
  return { generatedId, userId };
}
 
function chatOpen() {
  const params = updateUrlParams();
  if (!params) return; // Exit if generatedId is not provided
 
  document.getElementById("chat-open").style.display = "none";
  document.getElementById("chat-close").style.display = "block";
  document.getElementById("chat-window1").style.display = "block";
  document.getElementById("messageBox").innerHTML = ""; // Clear the message box
 
  generatedId = params.generatedId;
  userId = params.userId;
  console.log('Generated ID:', generatedId, 'User ID:', userId);
 
  audio1.load();
  audio1.play();
}
 
function chatClose() {
  document.getElementById("chat-open").style.display = "block";
  document.getElementById("chat-close").style.display = "none";
  document.getElementById("chat-window1").style.display = "none";
  document.getElementById("chat-window2").style.display = "none";
 
  audio1.load();
  audio1.play();
}
 
function openConversation() {
  document.getElementById("chat-window2").style.display = "block";
  document.getElementById("chat-window1").style.display = "none";
 
  audio1.load();
  audio1.play();
}
 
let generatedId, userId;
 
const urlParams = new URLSearchParams(window.location.search);
generatedId = urlParams.get('generatedId');
userId = urlParams.get('userId');
console.log('Initial params', { generatedId, userId });
 
// Gets the text from the input box(user)
function userResponse() {
  console.log("response");
  let userText = document.getElementById("textInput").value;
 
  if (userText.trim() === "") {
    alert("Please type something!");
  } else {
    document.getElementById("messageBox").innerHTML += `<div class="first-chat">
      <p>${userText}</p>
      <div class="arrow"></div>
    </div>`;
    let audio3 = new Audio("https://prodigits.co.uk/content/ringtones/tone/2020/alert/preview/4331e9c25345461.mp3");
    audio3.load();
    audio3.play();
 
    document.getElementById("textInput").value = "";
    var objDiv = document.getElementById("messageBox");
    objDiv.scrollTop = objDiv.scrollHeight;
 
    setTimeout(() => {
      sendToServer(userText);
    }, 1000);
  }
}
 
let chats = [];
// Send the user's message to the server and get a response
function sendToServer(userText) {
  chats.push({ role: "user", content: userText });
  console.log(chats[0]);
  fetch("http://localhost:3000/getAiResponse", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      generatedId: generatedId,
      userId: userId,
      userInput: chats[chats.length - 1].content,
    })
  })
    .then(response => response.json())
    .then(data => {
      const aiResponse = data[0].aiResponse;
      data.forEach(userResponse => {
        console.log(userResponse.aiResponse);
        console.log(userResponse.uniqueId);
        chats.push({ role: "bot", content: userResponse.aiResponse });
      });
      document.getElementById("messageBox").innerHTML += `<div class="second-chat">
        <div class="circle" id="circle-mar"></div>
        <p>${aiResponse}</p>
        <div class="arrow"></div>
      </div>`;
      let audio3 = new Audio("https://downloadwap.com/content2/mp3-ringtones/tone/2020/alert/preview/56de9c2d5169679.mp3");
      audio3.load();
      audio3.play();
 
      var objDiv = document.getElementById("messageBox");
      objDiv.scrollTop = objDiv.scrollHeight;
    })
    .catch(error => {
      console.error("Error:", error);
      displayFallbackResponse();
    });
}
 
// Display a fallback response if the server request fails
function displayFallbackResponse() {
  const aiResponse = "could not get response";
  document.getElementById("messageBox").innerHTML += `<div class="second-chat">
      <div class="circle" id="circle-mar"></div>
      <p>${aiResponse}</p>
      <div class="arrow"></div>
    </div>`;
  let audio3 = new Audio("https://downloadwap.com/content2/mp3-ringtones/tone/2020/alert/preview/56de9c2d5169679.mp3");
  audio3.load();
  audio3.play();
 
  var objDiv = document.getElementById("messageBox");
  objDiv.scrollTop = objDiv.scrollHeight;
}
 
// Press enter on keyboard and send message
addEventListener("keypress", (e) => {
  if (e.keyCode === 13) {
    const e = document.getElementById("textInput");
    if (e === document.activeElement) {
      userResponse();
    }
  }
});