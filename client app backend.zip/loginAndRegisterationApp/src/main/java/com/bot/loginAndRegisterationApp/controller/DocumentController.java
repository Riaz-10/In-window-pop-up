package com.bot.loginAndRegisterationApp.controller;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.text.Document;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
//import org.apache.poi.hwpf.HWPFDocuent;
import com.bot.loginAndRegisterationApp.dto.DocumentDto;
import com.bot.loginAndRegisterationApp.dto.DocumentResponse;
import com.bot.loginAndRegisterationApp.model.Documents;
import com.bot.loginAndRegisterationApp.service.DocumentService;




@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/documents")
public class DocumentController {
	
	@Autowired
    private DocumentService documentService;
	 private static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
 
   @GetMapping("/user/{userName}")
   public ResponseEntity<List<Documents>> getDocumentsByUserName(@PathVariable String userName) {
       List<Documents> documents = documentService.getDocumentsByUserName(userName);
       return new ResponseEntity<>(documents, HttpStatus.OK);
  }
 
    @PostMapping("/upload")
    public ResponseEntity<String> uploadDocument(
            @RequestParam("userName") String userName,
            @RequestParam("prompt") String prompt,
            @RequestParam("applicationName") String applicationName,
            @RequestParam(value = "file", required = false) MultipartFile[] file,
            @RequestParam(value = "urls", required = false) String urls,
            @RequestParam(value = "fileLink", required = false) String fileLink,
            @RequestParam(value = "apiKey", required=false)String apiKey,
            @RequestParam(value = "apiProvider", required=false)String apiProvider){
    	
   System.out.println(apiKey + apiProvider );

   if (file != null) {
	   for(MultipartFile x: file) {
		   if(x!=null && x.getSize()>MAX_FILE_SIZE) {
			   return new ResponseEntity<>("File size exceeds the maximum limit of 5MB", HttpStatus.BAD_REQUEST);
		   }
	   }
       
       
   }
        try {
            documentService.uploadDocument(userName, prompt ,applicationName, file, urls, fileLink,apiKey,apiProvider);
            return new ResponseEntity<>("Document uploaded successfully", HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>("Document upload failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
//    @GetMapping("/download/{id}")
//    public ResponseEntity<Resource> downloadDocument(@PathVariable String id) {
//        Documents document = documentService.getDocumentById(id);
//        if (document == null) {
//            return ResponseEntity.notFound().build();
//        }
////        List<byte[]> x = new ArrayList<document.getData()>;
//             		
//        		
//        		
//        ByteArrayResource resource = new ByteArrayResource(document.getData());
//        return ResponseEntity.ok()
//                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + document.getName())
//                .contentType(MediaType.parseMediaType(document.getType()))
//                .contentLength(document.getData().length)
//                .body(resource);
//    }
 
    
    
//    @GetMapping("/view/{id}")
//    public ResponseEntity<Resourc> viewDocument(@PathVariable String id) {
//        Documents document = documentService.getDocumentById(id);
//        if (document == null) {
//            return ResponseEntity.notFound().build();
//        }
// 
//        ByteArrayResource resource = new ByteArrayResource(document.getData());
//        return ResponseEntity.ok()
//                .contentType(MediaType.parseMediaType(document.getType()))
//                .contentLength(document.getData().length)
//                .body(resource);
//    }
    
    
    
    
//    
//    @GetMapping("/view/{userName}")//can view any first up document
//    public ResponseEntity<?> viewDocumentsByUserName(@PathVariable String userName) {
//        List<Documents> documents = documentService.getDocumentsByUserName(userName);
//        if (documents.isEmpty()) {
//            return ResponseEntity.notFound().build();
//        }
//        
// 
//        // Assuming you only want to return the first document for simplicity.
//        Documents document = documents.get(0);
//        String contentType = document.getType();
// 
//        if (contentType.startsWith("text") || contentType.equals("application/json") || contentType.equals("application/xml")) {
//            String content = new String(document.getData(), StandardCharsets.UTF_8);
//            return ResponseEntity.ok()
//                    .contentType(MediaType.parseMediaType(contentType))
//                    .body(content);
//        } else {
//            ByteArrayResource resource = new ByteArrayResource(document.getData());
//            return ResponseEntity.ok()
//                    .contentType(MediaType.parseMediaType(contentType))
//                    .contentLength(document.getData().length)
//                    .body(resource);
//        }
//    }
//    @GetMapping("/view/{userName}")//without pdf
//    public ResponseEntity<?> viewDocumentsByUserName(@PathVariable String userName) {
//
//        List<Documents> documents = documentService.getDocumentsByUserName(userName);
// 
//        if (documents.isEmpty()) {
//            
//            return ResponseEntity.notFound().build();
//        }
//       
// 
//        StringBuilder responseBuilder = new StringBuilder();
//        for (Documents document : documents) {
//            String contentType = document.getType();
//            if (contentType.startsWith("text") || contentType.equals("application/json") || contentType.equals("application/xml")) {
//                String content = new String(document.getData(), StandardCharsets.UTF_8);
//                responseBuilder.append(content).append("\n");
//            } else {
//                ByteArrayResource resource = new ByteArrayResource(document.getData());
//                // Append the resource content to the response
//                responseBuilder.append(resource).append("\n");
//            }
//        }
// 
//        return ResponseEntity.ok()
//        		.contentType(MediaType.TEXT_PLAIN) // Adjust content type as needed
//                .body(responseBuilder.toString());
//    }
//}
    
//  @GetMapping("/view/{userName}")//working
//    public ResponseEntity<?> viewDocumentsByUserName(@PathVariable String userName) {
//       List<Documents> documents = documentService.getDocumentsByUserName(userName);
//
//        if (documents.isEmpty()) {
//           
//           return ResponseEntity.notFound().build();
//      }
//
//       StringBuilder responseBuilder = new StringBuilder();
//       for (Documents document : documents) {
//           String contentType = document.getType();
//    
//           byte[] data = document.getData();
//              String apiKey = document.getApiKey();
//    
//              responseBuilder.append("API Key: ").append(apiKey).append("\n");
//              
//           if (contentType.startsWith("text")) {
//                String content = new String(data, StandardCharsets.UTF_8);
//                responseBuilder.append("Text Document:\n").append(content).append("\n\n");
//            } else if (contentType.equals("application/pdf")) {
//                String content = extractTextFromPdf(data);
//                responseBuilder.append("PDF Document:\n").append(content).append("\n\n");
//            } else if (contentType.equals("application/msword") || contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
//                String content = extractTextFromWord(data, contentType);
//                responseBuilder.append("Word Document:\n").append(content).append("\n\n");
//            } else {
//                responseBuilder.append("Unsupported document format: ").append(contentType).append("\n\n");
//            }
//        }
//    @GetMapping("/view/{userName}")//working
//    public ResponseEntity<?> viewDocumentsByUserName(@PathVariable String userName) {
//       List<Documents> documents = documentService.getDocumentsByUserName(userName);
// 
//        if (documents.isEmpty()) {
//           return ResponseEntity.notFound().build();
//      }
// 
//       StringBuilder responseBuilder = new StringBuilder();
//       for (Documents document : documents) {
//           String contentType = document.getType();
//           byte[] data = document.getData();
//              String apiKey = document.getApiKey();
//              responseBuilder.append("API Key: ").append(apiKey).append("\n");
//           if (contentType.startsWith("text")) {
//                String content = new String(data, StandardCharsets.UTF_8);
//                responseBuilder.append("contentType:"+contentType).append("\n\ncontent"+content).append("\n\n");
//            } else if (contentType.equals("application/pdf")) {
//                String content = extractTextFromPdf(data);
//                responseBuilder.append("contentType:application/pdf").append(content).append("\n\n");
//            } else if (contentType.equals("application/msword") || contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
//                String content = extractTextFromWord(data, contentType);
//                responseBuilder.append("contentType:application/docx").append(content).append("\n\n");
//            } else {
//                responseBuilder.append("Unsupported document format: ").append(contentType).append("\n\n");
//            }
//        }
//
// 
//        return ResponseEntity.ok()
//                .contentType(MediaType.TEXT_PLAIN)
//                .body(responseBuilder.toString());
//    }
// 
//    private String extractTextFromPdf(byte[] pdfData) {
//        try (PDDocument document = PDDocument.load(pdfData)) {
//            PDFTextStripper stripper = new PDFTextStripper();
//            return stripper.getText(document);
//        } catch (IOException e) {
//           
//            return "Error extracting text from PDF";
//        }
//    }
// 
//    private String extractTextFromWord(byte[] wordData, String contentType) {
//        try {
//            if (contentType.equals("application/msword")) { // DOC files
//                try (ByteArrayInputStream bis = new ByteArrayInputStream(wordData);
//                    HWPFDocument document = new HWPFDocument(bis)) {
//                  WordExtractor extractor = new WordExtractor(document);
//                    return extractor.getText();
//                }
//            } else if (contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { // DOCX files
//                try (ByteArrayInputStream bis = new ByteArrayInputStream(wordData);
//                     XWPFDocument document = new XWPFDocument(bis)) {
//                    XWPFWordExtractor extractor = new XWPFWordExtractor(document);
//                    return extractor.getText();
//                }
//            }
//        } catch (IOException e) {
//           
//            return "Error extracting text from Word document";
//        }
//        return "Unsupported Word document format";
//    }
    @GetMapping("/view/{userName}")
    public ResponseEntity<?> viewDocumentsByUserName(@PathVariable String userName) {
        List<Documents> documents = documentService.getDocumentsByUserName(userName);
     
        if (documents.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
     
        StringBuilder responseBuilder = new StringBuilder();
     
//        for (Documents document : documents) {
//            String contentType = document.getType();
//            byte[] data = document.getData();
//            String apiKey = document.getApiKey();
//     
//            responseBuilder.append("API Key: ").append(apiKey).append("\n");
//     
//            if (contentType.startsWith("text")) {
//                String content = new String(data, StandardCharsets.UTF_8);
//                responseBuilder.append("contentType: ").append(contentType).append("\n\n").append("content: ").append(content).append("\n\n");
//            } else if (contentType.equals("application/pdf")) {
//                String content = extractTextFromPdf(data);
//                responseBuilder.append("contentType: application/pdf").append("\n\n").append(content).append("\n\n");
//            } else if (contentType.equals("application/msword") || contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
//                String content = extractTextFromWord(data, contentType);
//                responseBuilder.append("contentType: application/docx").append("\n\n").append(content).append("\n\n");
//            } else if (contentType.equals("application/json")) {
//                String content = new String(data, StandardCharsets.UTF_8);
//                responseBuilder.append("contentType: application/json").append("\n\n").append(content).append("\n\n");
//            } else {
//                responseBuilder.append("Unsupported document format: ").append(contentType).append("\n\n");
//            }
//        }
     
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_PLAIN)
                .body(responseBuilder.toString());
    }
     
    private String extractTextFromPdf(byte[] pdfData) {
        try (PDDocument document = PDDocument.load(pdfData)) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(document);
        } catch (IOException e) {
            return "Error extracting text from PDF";
        }
    }
     
    private String extractTextFromWord(byte[] wordData, String contentType) {
        try {
            if (contentType.equals("application/msword")) { // DOC files
                try (ByteArrayInputStream bis = new ByteArrayInputStream(wordData);
                     HWPFDocument document = new HWPFDocument(bis)) {
                    WordExtractor extractor = new WordExtractor(document);
                    return extractor.getText();
                }
            } else if (contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { // DOCX files
                try (ByteArrayInputStream bis = new ByteArrayInputStream(wordData);
                     XWPFDocument document = new XWPFDocument(bis)) {
                    XWPFWordExtractor extractor = new XWPFWordExtractor(document);
                    return extractor.getText();
                }
            }
        } catch (IOException e) {
            return "Error extracting text from Word document";
        }
        return "Unsupported Word document format";
    }
    
}
    


    
    
    
    






	
	
 



