package com.bot.loginAndRegisterationApp.exception;

public class UserCredentialsMisMatch extends RuntimeException{

	public UserCredentialsMisMatch(String str) {
		super(str);
	}
}
