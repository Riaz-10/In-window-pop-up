package com.bot.loginAndRegisterationApp.repo;

import java.util.List;

//import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.bot.loginAndRegisterationApp.model.Documents;



public interface DocumentRepository extends MongoRepository<Documents, String> {
//	@Query("{ 'user.userName' : ?0 }")
	 List<Documents> findByUserUserName(String userName);
	
	@Query("{ 'user.userName' : ?0 , 'documents.applicationName' : ?1 }")
	 List<Documents> findByUserUserNameAndApplicationName(String userName, String applicationName);
}
