package com.bot.loginAndRegisterationApp.exception;

public class UserCredentialsNullException extends RuntimeException {
	public UserCredentialsNullException(String msg){
		super(msg);
	}
}
