package com.bot.loginAndRegisterationApp.repo;

//import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.stereotype.Repository;
import org.springframework.data.mongodb.repository.Query;

import com.bot.loginAndRegisterationApp.model.UserRegistration;


public interface UserRegistrationRepository extends MongoRepository<UserRegistration, Long>{
	
	UserRegistration findByUserName(String userName);

//    UserRegistration findByEmail(String email);

    UserRegistration findByPhoneNumber(String phoneNumber);
    
    @Query("{ 'email' : ?0 }")
	UserRegistration findByEmail(String email);
}


