package com.bot.loginAndRegisterationApp.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class MongoConfig {

}
