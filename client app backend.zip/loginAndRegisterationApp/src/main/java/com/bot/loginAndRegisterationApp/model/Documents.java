package com.bot.loginAndRegisterationApp.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;




@Document(collection = "documents")
public class Documents {
 
    @Id
    private String id;
 
    private List<String> name;
    private List<String> type;
    private String prompt;
    private String ApplicationName;
    private List<byte[]> data;
    public String getPrompt() {
		return prompt;
	}
	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}
	public String getApplicationName() {
		return ApplicationName;
	}
	public void setApplicationName(String applicationName) {
		ApplicationName = applicationName;
	}
	private String urls;
    private String fileLink;
    private String apiKey;
    private String apiProvider;
    private UserRegistration user;
    
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<String> getName() {
		return name;
	}
	public void setName(List<String> name) {
		this.name = name;
	}
	public List<String> getType() {
		return type;
	}
	public void setType(List<String> type) {
		this.type = type;
	}
	public List<byte[]> getData() {
		return data;
	}
	public void setData(List<byte[]> data) {
		this.data = data;
	}
	public String getUrls() {
		return urls;
	}
	public void setUrls(String urls) {
		this.urls = urls;
	}
	public String getFileLink() {
		return fileLink;
	}
	public void setFileLink(String fileLink) {
		this.fileLink = fileLink;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public String getApiProvider() {
		return apiProvider;
	}
	public void setApiProvider(String apiProvider) {
		this.apiProvider = apiProvider;
	}
	public UserRegistration getUser() {
		return user;
	}
	public void setUser(UserRegistration user) {
		this.user = user;
	}
	public Documents(String id, List<String> name, List<String> type, List<byte[]> data, String urls, String fileLink, String apiKey,
			String apiProvider, UserRegistration user) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.data = data;
		this.urls = urls;
		this.fileLink = fileLink;
		this.apiKey = apiKey;
		this.apiProvider = apiProvider;
		this.user = user;
	}
	public Documents() {
		super();
	}
	
    
    
}
