import express from 'express';
import {fetchUserAndProcess, getAiResponse ,llmCall,runAll } from './llm.js';
import bodyParser from 'body-parser';
import cors from 'cors';
import session from 'express-session';
import { Binary, MongoClient, ObjectId } from 'mongodb';
import fs from 'fs';
const app = express();
const port = 3000;
app.use(bodyParser.json());
app.use(cors());
app.use(session({
  secret: 'my-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false, maxAge: 60000 } // session cookie expires after 1 minute
}));





let llmResponses = {};
let chatHistory={};

llmResponses=await runAll();

//when start button is clicked in client application 
app.post('/llm', async (request, response) => {
  try {
    const { generatedId } = request.body;
    console.log(`Received request with generatedId: ${generatedId}`);
    const retrieval_Chain = await llmCall(generatedId);
    console.log('type in llm:',retrieval_Chain);
    llmResponses[generatedId] = retrieval_Chain;
    console.log(`Stored llmResponse for generatedId: ${generatedId} `+ llmResponses[generatedId]);
    const indexHtml = fs.readFileSync('chatbot/index.html','utf-8');
    const chatJs = fs.readFileSync('chatbot/chat.js','utf-8');
    response.json({ 
      html : indexHtml,
      js : chatJs
     });
  } catch (error) {
    console.error('Error processing request:', error);
    response.status(500).json({ error: 'An error occurred while processing the request.' });
  }
});

//generated unique id, end user id, end user input - multiple instances for end user
app.post('/getAiResponse', async (request, response) => {
  try {
    let { generatedId, userId, userInput } = request.body;
    console.log('user id:',userId);
    const idMap = { generatedId: userId };
    generatedId = [generatedId];
    const userResponses = await Promise.all(generatedId.map(async (generatedId) => {
    const uId = idMap[generatedId];
    const uniqueId = generatedId+userId;
    console.log('unique Id',uniqueId);
    const retrieval_Chain=llmResponses[generatedId];
    if (!chatHistory[uniqueId]) {
      console.log('history for ',uniqueId,' is empty');
      chatHistory[uniqueId] = [];
    }else{
      console.log('history for ',uniqueId,' is ',chatHistory[uniqueId]);
    }
    const aiResponse = await getAiResponse(userInput,retrieval_Chain,chatHistory[uniqueId]);
    chatHistory[uniqueId].push({ type: "user", text: userInput });
    chatHistory[uniqueId].push({ type: "ai", text: aiResponse });
    return { retrieval_Chain, aiResponse };
    }));
    // Return the separate AI responses for each user
    response.json(userResponses);
    
    //sepearte chat history for each unique id and user
  } catch (error) {
    console.error('Error processing request:', error);
    response.status(500).json({ error: 'An error occurred while processing the request.' });
  }
});
 

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});


