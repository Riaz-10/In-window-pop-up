import express from "express";
import { llmCall,getAiResponse } from "./llm.js";
import bodyParser from "body-parser";
import cors from "cors";
import { createClient } from "redis";
 
const app = express();
const port = 3000;
app.use(bodyParser.json());
app.use(cors());
 
// Redis connection details
const redisHost = "redis-13920.c241.us-east-1-4.ec2.redns.redis-cloud.com";
const redisPort = 13920; // Your Redis port
const redisPassword = "qFp4d2TXXVkP40gCuqkYq2fbPYvt6V1L";
 
// Create a Redis client
const client = createClient();
 
// Handle connection errors
client.on("error", (err) => {
  console.error("Redis error:", err);
});
 
// Confirm Redis connection
client.on("connect", () => {
  console.log("Connected to Redis");
});
const chatHistory={};
(async () => {
  try {
    // Connect to Redis
    await client.connect();
 
    app.post("/llm", async (request, response) => {
      try {
        // Extract generatedId from the request body
        const { generatedId } = request.body;
        console.log(`received request with generatedId: ${generatedId}`);
 
        // Call llmCall method and get the result
        const retrieval_Chain = await llmCall(generatedId);
        // Store the result in Redis
        await client.set(generatedId, JSON.stringify(retrieval_Chain));
        console.log(
          `Stored llmResponse in Redis for generatedId: ${generatedId}`
        );
        response.json({ success: true });
      } catch (error) {
        console.error("Error processing request:", error);
        response
          .status(500)
          .json({ error: "An error occurred while processing the request." });
      }
    });

    app.post('/getAiResponse', async (request, response) => {
      try {
        let { generatedId, userId, userInput } = request.body;
        console.log('user id:',userId);
        const idMap = { generatedId: userId };
        generatedId = [generatedId];
        const userResponses = await Promise.all(generatedId.map(async (generatedId) => {
        const uId = idMap[generatedId];
        const uniqueId = generatedId+userId;
        console.log('unique Id',uniqueId);
        const retrieval_Chain = await client.get(generatedId);
        console.log('retrieval chain is', retrieval_Chain);
        if (!chatHistory[uniqueId]) {
          console.log('history for ',uniqueId,' is empty');
          chatHistory[uniqueId] = [];
        }else{
          console.log('history for ',uniqueId,' is ',chatHistory[uniqueId]);
        }
        const aiResponse = await getAiResponse(userInput,retrieval_Chain,chatHistory[uniqueId]);
        chatHistory[uniqueId].push({ type: "user", text: userInput });
        chatHistory[uniqueId].push({ type: "ai", text: aiResponse });
        return { retrieval_Chain, aiResponse };
        }));
        // Return the separate AI responses for each user
        response.json(userResponses);
        
        //sepearte chat history for each unique id and user
      } catch (error) {
        console.error('Error processing request:', error);
        response.status(500).json({ error: 'An error occurred while processing the request.' });
      }
    });
    
 
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  } catch (error) {
    console.error("Failed to connect to Redis:", error);
  }
})();
 
 