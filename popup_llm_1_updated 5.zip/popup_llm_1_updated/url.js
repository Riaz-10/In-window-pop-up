import {CheerioWebBaseLoader} from "@langchain/community/document_loaders/web/cheerio";
const loader = new CheerioWebBaseLoader("https://www.itchotels.com/in/en/itckohenur-hyderabad");
const docs = await loader.load();
console.log(docs);