import { GoogleGenerativeAIEmbeddings } from "@langchain/google-genai";
import { TaskType } from "@google/generative-ai";
import * as dotenv from "dotenv";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";
import { createRetrievalChain } from "langchain/chains/retrieval";
import { Binary, MongoClient, ObjectId } from 'mongodb';
import pdf from 'pdf-parse';
import {Document, Packer} from 'docx';
dotenv.config();

import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import { HarmBlockThreshold, HarmCategory } from "@google/generative-ai";

//const uri = 'mongodb+srv://admin:2222731@cluster0.g6peabc.mongodb.net/';
const uri ='mongodb://127.0.0.1:27017/';
const dbName = 'userdb';
const collectionName = 'documents';
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

async function fetchUserAndProcess(generatedId) {
  try {
    console.log('inside fetch db');
    await client.connect();
    console.log('line 24');
    const database = client.db(dbName);
    console.log('line 26');
    const collection = database.collection(collectionName);
    console.log('line 28');
    const user = await collection.findOne({ _id: generatedId});
    console.log('line 31');
    if (!user) {
      console.error('User not found');
      return null;
    }
    const {apiKey,prompt} = user;
    const userPrompt=prompt+`<context>
    {context}
    </context>
    chat history:
    {chat_history}`;
    //const content = data.buffer.toString('utf-8');
    //const contentArray = data.map((binary) => binary.buffer.toString('utf-8'));

    let combinedContent = '';

    for (let i=0;i<user.data.length;i++) {
      const data = user.data[i];
      const mimeType = user.type[i];
      let content = '';

      if (mimeType === 'text/plain') {
        content = data.buffer.toString('utf-8');
      } else if (mimeType === 'application/pdf') {
        content = await extractPdfContent(data.buffer);
      } else if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        content = await extractDocxContent(data.buffer);
      }
      combinedContent += content + '\n';
    }
    console.log('content:',combinedContent);
    console.log('apikey:',apiKey);
    console.log('prompt:',userPrompt);
    return {content:combinedContent,apiKey,userPrompt};
  }catch (error) {
    console.error('Error fetching user or processing request:', error);
  } finally {
    await client.close();
  }
}


async function extractPdfContent(buffer) {
  try {
    const data = await pdf(buffer);
    return data.text;
  } catch (error) {
    console.error('Error extracting PDF content:', error);
    return '';
  }
}

async function extractDocxContent(buffer) {
  try {
    const doc = new Document(buffer);
    const extracted = await Packer.toBuffer(doc);
    return extracted.toString();
  } catch (error) {
    console.error('Error extracting DOCX content:', error);
    return '';
  }
}


async function llmCall(generatedId) {


  console.log("--------inside llm call----");
  console.log(generatedId);
  const {content,apiKey,userPrompt}=await fetchUserAndProcess(generatedId);
  const embeddings = new GoogleGenerativeAIEmbeddings({
    apiKey: apiKey,
    model: "embedding-001", // 768 dimensions
    taskType: TaskType.RETRIEVAL_DOCUMENT,
    title: "Document title",
  });
  const docs = [{ pageContent: content }];
  const vectorstore = await MemoryVectorStore.fromDocuments(docs, embeddings);
  const retriever = vectorstore.asRetriever();
  console.log("--------retrieved----");
  //llm
  const chatModel = new ChatGoogleGenerativeAI({
    apiKey: apiKey,
    model: "gemini-pro",
    maxOutputTokens: 2048,
    temperature: 0,
    verbose: true,
    safetySettings: [
      {
        category: HarmCategory.HARM_CATEGORY_HARASSMENT,
        threshold: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
      },
    ],
  });
  const template=userPrompt;
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", template],
    ["human", "user: {input}"],
  ]);
  //console.log("--------prompt----", prompt);
  const documentChain = await createStuffDocumentsChain({
    llm: chatModel,
    prompt,
  });
  const retrievalChain = await createRetrievalChain({
    combineDocsChain: documentChain,
    retriever,
  });
  console.log("--------exiting llm -------------------");
  return retrievalChain;
}
//  let input = "hi";
const getAiResponse = async (userInput, retrievalChain,chatHistory) => {
  console.log("------------in  getAiResponse--------");
  console.log("user input:", userInput);
  const retrievalResult = await retrievalChain.invoke({
    input: userInput,
    chat_history: JSON.stringify(chatHistory),
  });


  console.log("--------chathistory---------", chatHistory);

  console.log("----retrieval response------------", retrievalResult.answer);
  return retrievalResult.answer;
};

async function runAll() {
  try{
    await client.connect();
    const database = client.db(dbName);
    const collection = database.collection(collectionName);
    const documents = await collection.find({}).toArray();
    if (!documents) {
      console.error('docs not found');
      return null;
    }
    const llmResponses = {};
    for(const doc of documents){
      const generatedId = doc._id;
      const retrieval_Chain = await llmCall(generatedId);
      llmResponses[generatedId] = retrieval_Chain;
      console.log('stored llm response for ', generatedId);
    }
    return llmResponses;
    
  }catch (error) {
    console.error('Error fetching user or processing request:', error);
  } finally {
    await client.close();
  }
}


export { getAiResponse, llmCall,fetchUserAndProcess,runAll };
