import { TestBed } from '@angular/core/testing';

import { LLMStatusService } from './llmstatus.service';

describe('LLMStatusService', () => {
  let service: LLMStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LLMStatusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
