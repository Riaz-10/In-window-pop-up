// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class LLMStatusService {

//   constructor() { }
// }


import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LLMStatusService {
  private statusMap: Map<string, boolean> = new Map();
  private responseMap: Map<string, string> = new Map();

  setStatus(generatedId: string, isRunning: boolean): void {
    this.statusMap.set(generatedId, isRunning);
    localStorage.setItem(`isRunning_${generatedId}`, isRunning ? 'true' : 'false');
  }

  getStatus(generatedId: string): boolean {
    const statusFromStorage = localStorage.getItem(`isRunning_${generatedId}`);
    if (statusFromStorage !== null) {
      return statusFromStorage === 'true';
    }
    return this.statusMap.get(generatedId) || false;
  }



  saveResponse(id: string, response: string): void {
    this.responseMap.set(id, response);
    localStorage.setItem(`response_${id}`, response);
  }

  getResponse(id: string): string {
    return this.responseMap.get(id) || localStorage.getItem(`response_${id}`) || '';
  }
}
