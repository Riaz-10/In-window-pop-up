export class UserReg {

          id   ! : BigInt;
          userName   ! : string;
          password   ! : string;
          firstName   ! : string;
          lastName   ! : string;
          email   ! : string;
          phoneNumber   ! : string;
}
