import { UploadDocuments } from './upload-documents';

describe('UploadDocuments', () => {
  it('should create an instance', () => {
    expect(new UploadDocuments()).toBeTruthy();
  });
});
