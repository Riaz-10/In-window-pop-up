// import { Component } from '@angular/core';
// import { UploadDocumentService } from '../upload-document.service';
// import Swal from 'sweetalert2';
// import { ActivatedRoute, Router } from '@angular/router';
// import { UploadDocuments } from '../upload-documents';
// import { SharedService } from '../shared.service';


// @Component({
//   selector: 'app-history',
//   templateUrl: './history.component.html',
//   styleUrl: './history.component.css'
// })
// export class HistoryComponent {
//     con: boolean=false;
//     constructor(private uploadDocumentService:UploadDocumentService,private route: ActivatedRoute,private router:Router,private sharedService: SharedService) {}
//     userName:any;
//     uploadDocuments : UploadDocuments[] =[];
//     show : UploadDocuments | null | undefined;
    
//     ngOnInit(): void {
      
//       this.userName=sessionStorage.getItem("userName");
//       console.log(this.userName);

//     //   this.formData = this.sharedService.getFormData();
//     // this.uniqueId = this.formData.get("userName") + this.formData.get("applicationName");

//       this.uploadDocumentService.getDocumentsByUserName(this.userName).subscribe(data =>{
//         this.uploadDocuments=data;
//         console.log(data);
//         console.log(this.uploadDocuments);
//       });
//     }

//     navigateToBack(){
//       this.router.navigate(['/dashboard'])
//     }

//     display(id:string)
//     {
//       this.con=true;
//       this.uploadDocumentService.getDocumentByDocId(id).subscribe(val =>{
//         this.show=val;
//         console.log(val);
//         console.log(this.show);
//     });
//   }
//     noDisplay(){
//       this.con=false;
//       this.show=null;
//     }
    
//     deleteId(id:string){
    
//     if(confirm('Are you sure you want to delete this document')){
//       this.uploadDocumentService.deleteDocumentByDocId(id).subscribe(
//         response =>{
//           console.log(response);
//           this.uploadDocuments = this.uploadDocuments.filter(doc => doc.id !== id);
//           Swal.fire("","Deleted Successfully","success");
//         },
//         error =>{
//           console.error("Error deleting document" , error);
//         }
//       )
//     }
//   }

//   showUpdateFormFlag: boolean = false;
//   selectedDocument: UploadDocuments = {} as UploadDocuments;
//   showUpdateForm(doc: UploadDocuments) {
//     this.selectedDocument = { ...doc };
//     this.showUpdateFormFlag = true;
//   }
//   closeUpdateForm() {
//     this.showUpdateFormFlag = false;
//   }
//   updateDocument() {
//     this.uploadDocumentService.updateDocument(this.selectedDocument).subscribe(response => {
//       Swal.fire('Success', 'Document updated successfully', 'success');
//       this.ngOnInit();  
//       this.showUpdateFormFlag = false;

//     }, error => {
//       Swal.fire('Error', 'Failed to update document', 'error');
//     });
//   }

//   formData: any;
//   uniqueId: any;
//   response: any;
//   isRunning: boolean = false;

//   onButtonClick(): void {
//     this.isRunning = true;
//     this.sharedService.getResponse(this.uniqueId).subscribe(
//       (data: any) => {
//         this.response = data;
//         this.isRunning = false;
//       },
//       (error: any) => {
//         console.error(error);
//         this.isRunning = false;
//       }
//     );
//   }
// }








import { Component } from '@angular/core';
import { UploadDocumentService } from '../upload-document.service';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
import { UploadDocuments } from '../upload-documents';
import { SharedService } from '../shared.service';
import { LLMStatusService } from '../../llmstatus.service';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrl: './history.component.css'
})
export class HistoryComponent {
  con: boolean = false;
  uploadDocuments: UploadDocuments[] = [];
  show: UploadDocuments | null | undefined;

  constructor(
    private uploadDocumentService: UploadDocumentService,
    private route: ActivatedRoute,
    private router: Router,
    private sharedService: SharedService,
    private llmStatusService: LLMStatusService
  ) {}

  ngOnInit(): void {
    
    const userName = sessionStorage.getItem("userName");
    if(userName){
    this.uploadDocumentService.getDocumentsByUserName(userName).subscribe(data => {
      this.uploadDocuments = data;

      // Update the running state for each document
      // this.uploadDocuments.forEach(doc => {
      //   const generatedId = doc.userName + '_' + doc.applicationName;
      //   doc.isRunning = localStorage.getItem(`isRunning_${generatedId}`) === 'true';
      // });

      
this.uploadDocuments.forEach(doc => {
  // const generatedId = doc.userName + '_' + doc.applicationName;
  const generatedId = doc.id;
  doc.isRunning = this.llmStatusService.getStatus(generatedId);
});
    });
  }
  }

  onButtonClick(doc: UploadDocuments): void {
    if ( !doc.isRunning) {
      doc.isRunning = true;
      // const generatedId = doc.userName + '_' + doc.applicationName;
      const generatedId = doc.id;
      localStorage.setItem(`isRunning_${generatedId}`, 'true');

      this.sharedService.getResponse(generatedId).subscribe(
        (data: any) => {
          // Handle response if needed
        },
        (error: any) => {
          console.error(error);
          doc.isRunning = false;
          localStorage.setItem(`isRunning_${generatedId}`, 'false');
        }
      );
    }
  }

  display(id: string) {
    this.con = true;
    this.uploadDocumentService.getDocumentByDocId(id).subscribe(val => {
      this.show = val;
    });
  }

  noDisplay() {
    this.con = false;
    this.show = null;
  }

  deleteId(id: string) {
    if (confirm('Are you sure you want to delete this document')) {
      this.uploadDocumentService.deleteDocumentByDocId(id).subscribe(
        response => {
          this.uploadDocuments = this.uploadDocuments.filter(doc => doc.id !== id);
          Swal.fire("", "Deleted Successfully", "success");
        },
        error => {
          console.error("Error deleting document", error);
        }
      );
    }
  }

  showUpdateFormFlag: boolean = false;
  selectedDocument: UploadDocuments = {} as UploadDocuments;

  showUpdateForm(doc: UploadDocuments) {
    this.selectedDocument = { ...doc };
    this.showUpdateFormFlag = true;
  }

  closeUpdateForm() {
    this.showUpdateFormFlag = false;
  }

      navigateToBack(){
      this.router.navigate(['/dashboard'])
    }

  updateDocument() {
    this.uploadDocumentService.updateDocument(this.selectedDocument).subscribe(
      response => {
        Swal.fire('Success', 'Document updated successfully', 'success');
        this.ngOnInit();  
        this.showUpdateFormFlag = false;
      },
      error => {
        Swal.fire('Error', 'Failed to update document', 'error');
      }
    );
  }
}

