// import { Component, OnInit } from '@angular/core';
// import { SharedService } from '../shared.service';
 
// @Component({
//   selector: 'app-submitted-details',
//   templateUrl: './submitted-details.component.html',
//   styleUrls: ['./submitted-details.component.css']
// })
// export class SubmittedDetailsComponent implements OnInit {
//   formData: any;
//   uniqueId: any;
//   response: any;
//   isRunning: boolean = false;
 
//   constructor(private sharedService: SharedService) { }
 
//   ngOnInit(): void {
//     this.formData = this.sharedService.getFormData();
//     this.uniqueId = this.formData.get("userName") + this.formData.get("applicationName");
//   }
 
//   onButtonClick(): void {
//     this.isRunning = true;
//     this.sharedService.getResponse(this.uniqueId).subscribe(
//       (data: any) => {
//         this.response = data;
//         this.isRunning = false;
//       },
//       (error: any) => {
//         console.error(error);
//         this.isRunning = false;
//       }
//     );
//   }
// }




// import { Component, OnInit } from '@angular/core';
// import { SharedService } from '../shared.service';
 
// @Component({
//   selector: 'app-submitted-details',
//   templateUrl: './submitted-details.component.html',
//   styleUrls: ['./submitted-details.component.css']
// })
// export class SubmittedDetailsComponent implements OnInit {
//   formData: any;
//   generatedId: any;
//   response: any;
//   isRunning: boolean = false;
//   hasStarted: boolean = false;
 
//   constructor(private sharedService: SharedService) { }
 
//   ngOnInit(): void {
//     this.formData = this.sharedService.getFormData();
//     this.generatedId = this.formData.get("userName") +'_' + this.formData.get("applicationName");
//   }
//   onButtonClick(): void {
//     this.isRunning = true;
//     this.hasStarted =false;
//     this.sharedService.getResponse(this.generatedId).subscribe(
//       (data: any) => {
//         this.response = data.html + 'JS FILE \n'+ data.js;
//       //  this.isRunning = false;
//       },
//       (error: any) => {
//         console.error(error);
//         this.isRunning = false;
//       }
//     );
//   }
// }




// import { Component, OnInit } from '@angular/core';
// import { SharedService } from '../shared.service';
// import { UploadDocuments } from '../upload-documents';
// import { LLMStatusService } from '../../llmstatus.service';

// @Component({
//   selector: 'app-submitted-details',
//   templateUrl: './submitted-details.component.html',
//   styleUrls: ['./submitted-details.component.css']
// })
// export class SubmittedDetailsComponent implements OnInit {
//   formData: any;
//   generatedId: any;
//   response: any;
//   isRunning: boolean = false;
//   uploadDocuments: UploadDocuments[] = [];
//   // doc:UploadDocuments;

//   constructor(private sharedService: SharedService,private llmStatusService: LLMStatusService) {
//     // this.doc=new  UploadDocuments();
//    }

//   ngOnInit(): void {
//     this.formData = this.sharedService.getFormData();
//     this.generatedId = this.formData.get('userName') + '_' + this.formData.get('applicationName');

//     // Retrieve running state if it was saved previously
//     const runningState = localStorage.getItem(`isRunning_${this.generatedId}`);
//     this.isRunning = runningState === 'true';
//   }

//   // onButtonClick(): void {
//   //   if (!this.isRunning) {
//   //     this.isRunning = true;
//   //     localStorage.setItem(`isRunning_${this.generatedId}`, 'true');
//   //     this.sharedService.getResponse(this.generatedId).subscribe(
//   //       (data: any) => {
//   //         this.response = data.html + 'JS FILE \n' + data.js;
//   //       },
//   //       (error: any) => {
//   //         console.error(error);
//   //         this.isRunning = false;
//   //         localStorage.setItem(`isRunning_${this.generatedId}`, 'false');
//   //       }
//   //     );
//   //   }
//   // }



//   onButtonClick(doc: UploadDocuments): void {
//     const generatedId = doc.userName + '_' + doc.applicationName;
    
//     if (!this.llmStatusService.getStatus(generatedId)) {
//       this.llmStatusService.setStatus(generatedId, true);
  
//       this.sharedService.getResponse(generatedId).subscribe(
//         (data: any) => {
//           this.response = data.html + 'JS FILE \n' + data.js;
//         },
//         (error: any) => {
//           console.error(error);
//           this.llmStatusService.setStatus(generatedId, false);
//         }
//       );
//     }
//   }


//   // onButtonClick(doc: UploadDocuments): void {
//   //   if ( !doc.isRunning) {
//   //     doc.isRunning = true;
//   //     const generatedId = doc.userName + '_' + doc.applicationName;
//   //     localStorage.setItem(`isRunning_${generatedId}`, 'true');

//   //     this.sharedService.getResponse(generatedId).subscribe(
//   //       (data: any) => {
//   //         this.response = data.html + 'JS FILE \n' + data.js;
//   //         // Handle response if needed
//   //       },
//   //       (error: any) => {
//   //         console.error(error);
//   //         doc.isRunning = false;
//   //         localStorage.setItem(`isRunning_${generatedId}`, 'false');
//   //       }
//   //     );
//   //   }
//   // }
  
// }














import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { UploadDocuments } from '../upload-documents';
import { LLMStatusService } from '../../llmstatus.service';

@Component({
  selector: 'app-submitted-details',
  templateUrl: './submitted-details.component.html',
  styleUrls: ['./submitted-details.component.css']
})
export class SubmittedDetailsComponent implements OnInit {
  formData: any;
  generatedId: string = '';
  response: string = '';
  response1:string='';
  isRunning: boolean = false;

  constructor(
    private sharedService: SharedService,
    private llmStatusService: LLMStatusService
  ) {}

  ngOnInit(): void {
    this.formData = this.sharedService.getFormData();
    if (this.formData) {
      this.generatedId = `${this.formData.get('userName')}_${this.formData.get('applicationName')}`;

      // Check the running status from the service
      this.isRunning = this.llmStatusService.getStatus(this.generatedId);

      // If running, load the response from storage or service if needed
      if (this.isRunning) {
        this.response = this.llmStatusService.getResponse(this.generatedId);
      }
    }
  }



  copyResponse(event: MouseEvent) {
    const responseText = this.response;
    const textarea = document.createElement('textarea');
    textarea.value = responseText;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    
    // Add the 'show' class to the .copied-msg element
    const target = event.target as HTMLElement;
    if (target) {
      const copiedMsg = target.nextElementSibling as HTMLElement;
      if (copiedMsg) {
        copiedMsg.classList.add('show');
        
        // Remove the 'show' class after 2 seconds
        setTimeout(() => {
          copiedMsg.classList.remove('show');
        }, 2000);
      }
    }
  }

  onButtonClick(): void {
    if (!this.isRunning) {
      this.isRunning = true;
      this.llmStatusService.setStatus(this.generatedId, true);

      this.sharedService.getResponse(this.generatedId).subscribe(
        (data: any) => {
          this.response = `${data.html}`;
          this.response1=`${data.js}`;
          this.llmStatusService.saveResponse(this.generatedId, this.response);
        },
        (error: any) => {
          console.error(error);
          this.isRunning = false;
          this.llmStatusService.setStatus(this.generatedId, false);
        }
      );
    }
  }
}
