import { UserReg } from './user-reg';

describe('UserReg', () => {
  it('should create an instance', () => {
    expect(new UserReg()).toBeTruthy();
  });
});
